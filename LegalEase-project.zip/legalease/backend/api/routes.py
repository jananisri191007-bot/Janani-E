from fastapi import APIRouter, HTTPException

from backend.ai_core.gemini_generator import GeminiDocumentGenerator
from backend.config import get_settings
from backend.schemas import DocumentRequest, DocumentResponse

router = APIRouter()

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest) -> DocumentResponse:
    settings = get_settings()
    total = len(request.document_type) + len(request.parties) + len(request.terms) + len(request.dates)
    if total > settings.max_input_chars:
        raise HTTPException(status_code=413, detail="Input is too large. Please shorten the document details.")
    try:
        generator = GeminiDocumentGenerator()
        content = generator.generate_document(
            request.document_type, request.parties, request.terms, request.dates
        )
        return DocumentResponse(document_type=request.document_type, content=content, model=settings.gemini_model)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI generation failed: {exc}") from exc
