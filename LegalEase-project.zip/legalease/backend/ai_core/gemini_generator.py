from google import genai
from google.genai import types

from backend.config import get_settings

SYSTEM_INSTRUCTION = """
You are LegalEase's legal-document drafting assistant. Generate a structured draft from the
user's supplied facts. Do not invent names, dates, amounts, addresses, jurisdictions, or other
material facts. Preserve user-provided facts accurately. Use professional legal drafting style,
clear headings, numbered sections, and complete sentences. If a fact is missing and is necessary,
use a clearly marked placeholder such as [INSERT ...] rather than guessing.

This is drafting assistance, not legal advice. Do not claim that the document is legally valid,
compliant, or suitable for a particular jurisdiction unless the user explicitly supplies that
jurisdiction and asks for a jurisdiction-specific draft. Include a brief "Drafting Notice" at the
end stating that the document should be reviewed by a qualified legal professional before signing.
"""

class GeminiDocumentGenerator:
    def __init__(self) -> None:
        settings = get_settings()
        if not settings.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env before generating documents.")
        self.settings = settings
        self.client = genai.Client(api_key=settings.gemini_api_key)

    def generate_document(self, document_type: str, parties: str, terms: str, dates: str) -> str:
        prompt = f"""
Draft a {document_type} using only the information below.

Document type:
{document_type}

Parties:
{parties}

Terms and conditions:
{terms}

Effective date / dates:
{dates}

Formatting requirements:
- Start with a clear document title.
- Include an introductory paragraph identifying the parties and effective date.
- Organize substantive provisions under numbered headings.
- Convert semicolon-separated terms into distinct provisions where appropriate.
- Include signature blocks for the relevant parties.
- Do not add fictional facts.
- End with a short Drafting Notice.
"""
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION,
                temperature=self.settings.model_temperature,
                max_output_tokens=self.settings.model_max_output_tokens,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()
