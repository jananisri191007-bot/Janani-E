from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "LegalEase"
    environment: str = "development"
    gemini_api_key: str | None = None
    gemini_model: str = "gemini-3.8-flash"
    backend_host: str = "0.0.0.0"
    backend_port: int = 8000
    frontend_url: str = "http://localhost:8501"
    max_input_chars: int = 20000
    model_temperature: float = 0.2
    model_max_output_tokens: int = 8000
    request_timeout_seconds: int = 120

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

@lru_cache
def get_settings() -> Settings:
    return Settings()
