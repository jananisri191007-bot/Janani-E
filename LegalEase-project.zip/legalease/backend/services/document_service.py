from io import BytesIO
import html
import re
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.shared import Inches, Pt
from fpdf import FPDF

ASSETS_DIR = Path(__file__).resolve().parents[2] / "assets"
LOGO_PATH = ASSETS_DIR / "legalease_logo.png"


def sanitize_text(text: str) -> str:
    replacements = {
        "“": '"', "”": '"', "‘": "'", "’": "'", "–": "-", "—": "-", "•": "-", "\u00a0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return re.sub(r"\r\n?", "\n", text).strip()


def _lines(text: str) -> list[str]:
    return [line.strip() for line in sanitize_text(text).split("\n") if line.strip()]


def format_html_preview(text: str) -> str:
    blocks = []
    for line in _lines(text):
        escaped = html.escape(line)
        if re.match(r"^(\d+\.?|[A-Z][A-Z\s&-]{3,}|DRAFTING NOTICE)\s*", line):
            blocks.append(f"<h3>{escaped}</h3>")
        elif line.startswith(("- ", "* ", "• ")):
            blocks.append(f"<li>{html.escape(line[2:].strip())}</li>")
        else:
            blocks.append(f"<p>{escaped}</p>")
    return "<article class='legal-preview'>" + "".join(blocks) + "</article>"


def format_docx(text: str, doc_type: str, terms: str | None = None) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"].font.size = Pt(11)
    styles["Title"].font.name = "Times New Roman"
    styles["Title"].font.size = Pt(18)

    if LOGO_PATH.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(LOGO_PATH), width=Inches(1.6))

    title = doc.add_paragraph(style="Title")
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.add_run(doc_type.upper())

    for line in _lines(text):
        if re.match(r"^(\d+\.?\s+.+|DRAFTING NOTICE\s*:?)$", line) and len(line) < 120:
            p = doc.add_paragraph()
            run = p.add_run(line)
            run.bold = True
            run.font.name = "Times New Roman"
            run.font.size = Pt(12)
        elif line.startswith(("- ", "* ", "• ")):
            doc.add_paragraph(line[2:].strip(), style="List Bullet")
        else:
            doc.add_paragraph(line)

    if terms:
        items = [item.strip() for item in terms.split(";") if item.strip()]
        if items:
            doc.add_heading("Key Terms", level=2)
            table = doc.add_table(rows=1, cols=2)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            table.style = "Table Grid"
            table.rows[0].cells[0].text = "#"
            table.rows[0].cells[1].text = "Term"
            for index, item in enumerate(items, 1):
                cells = table.add_row().cells
                cells[0].text = str(index)
                cells[1].text = item

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("LegalEase - AI-assisted drafting. Review before signing.").italic = True

    output = BytesIO()
    doc.save(output)
    return output.getvalue()


class BrandedPDF(FPDF):
    def __init__(self, title: str):
        super().__init__()
        self.doc_title = title
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        if LOGO_PATH.exists():
            self.image(str(LOGO_PATH), x=90, y=8, w=30)
            self.ln(18)
        self.set_font("Times", "B", 10)
        self.cell(0, 6, self.doc_title, align="C")
        self.ln(8)

    def footer(self):
        self.set_y(-14)
        self.set_font("Times", "I", 8)
        self.cell(0, 8, "LegalEase - AI-assisted drafting. Review before signing.", align="C")


def format_pdf(text: str, doc_type: str) -> bytes:
    pdf = BrandedPDF(doc_type)
    pdf.set_title(doc_type)
    pdf.add_page()
    pdf.set_font("Times", size=11)
    for line in _lines(text):
        if re.match(r"^(\d+\.?\s+.+|DRAFTING NOTICE\s*:?)$", line) and len(line) < 120:
            pdf.set_font("Times", "B", 12)
            pdf.multi_cell(0, 7, line)
            pdf.set_font("Times", size=11)
        elif line.startswith(("- ", "* ", "• ")):
            pdf.multi_cell(0, 6, "- " + line[2:].strip())
        else:
            pdf.multi_cell(0, 6, line)
        pdf.ln(1)
    return bytes(pdf.output())
