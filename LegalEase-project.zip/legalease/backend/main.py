from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.api.routes import router
from backend.config import get_settings
from backend.schemas import HealthResponse

settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0", description="AI-assisted legal document drafting API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url, "http://localhost:8501", "http://127.0.0.1:8501"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", response_model=HealthResponse)
def root() -> HealthResponse:
    return HealthResponse(status="ok", service=settings.app_name, ai_configured=bool(settings.gemini_api_key))

@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return root()

app.include_router(router)
