# LegalEase — AI-Powered Legal Document Generator

LegalEase is a Streamlit frontend + FastAPI backend + Google Gemini document-drafting application. It accepts a document type, parties, terms, and effective date, generates a structured draft, provides an editable preview, and exports TXT, DOCX, and PDF files.

The architecture follows the supplied project documentation while using Google's current `google-genai` Python SDK instead of the older `google-generativeai` package.

## Project structure

```text
legalease/
├── backend/
│   ├── ai_core/gemini_generator.py
│   ├── api/routes.py
│   ├── services/document_service.py
│   ├── config.py
│   ├── schemas.py
│   └── main.py
├── frontend/app.py
├── assets/legalease_logo.png   # optional
├── tests/test_api.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. VS Code setup

Install Python 3.10+ and VS Code. Open the `legalease` folder in VS Code and open **Terminal → New Terminal**.

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 2. Configure Gemini

Open `.env` and set:

```env
GEMINI_API_KEY=your_real_key
GEMINI_MODEL=gemini-3.8-flash
```

The application reads `GEMINI_API_KEY` server-side. Never put the key in Streamlit UI code or commit `.env` to Git.

## 3. Run the backend

From the project root:

```powershell
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

Check `http://localhost:8000/` and `http://localhost:8000/docs`.

## 4. Run the frontend

Open a second VS Code terminal, activate the same virtual environment, then:

```powershell
streamlit run frontend/app.py
```

Open the Streamlit URL shown in the terminal, normally `http://localhost:8501`.

## 5. Test

Run unit/API tests from the project root:

```powershell
pytest -q
```

The tests mock Gemini, so they do not consume API quota.

## 6. End-to-end test

1. Start FastAPI.
2. Start Streamlit.
3. Enter a document type such as `Freelance Work Contract`.
4. Enter parties such as `Jane Doe (Service Provider), TechNova Inc. (Client)`.
5. Enter semicolon-separated terms.
6. Choose an effective date.
7. Click **Generate Document**.
8. Review and edit the generated draft.
9. Download TXT, DOCX, and PDF.

## Optional logo

Put a PNG named `legalease_logo.png` in `assets/`. DOCX and PDF exports automatically use it. If absent, exports continue without the logo.

## API

### POST `/generate`

Request:

```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)",
  "terms": "Confidentiality applies for 2 years; No disclosure to third parties",
  "dates": "2026-09-29"
}
```

Response:

```json
{
  "document_type": "Non-Disclosure Agreement",
  "content": "...generated draft...",
  "model": "gemini-3.8-flash"
}
```

## Design notes

- The backend owns the Gemini API key.
- Pydantic validates API input.
- CORS permits the local Streamlit frontend.
- Generated content is sanitized before display/export.
- DOCX uses Times New Roman, title formatting, a terms table, and a footer.
- PDF uses a branded header/footer and automatic page breaks.
- The frontend can edit the generated text before export.
- Missing Gemini credentials produce a clear HTTP 503 instead of a silent failure.

## Legal and production considerations

This application is an AI-assisted drafting tool, not a substitute for a lawyer. For production use, add authentication, rate limiting, audit logging, encrypted storage where applicable, jurisdiction-aware templates/review, structured secrets management, monitoring, and a formal privacy/data-retention policy before handling sensitive client information.
