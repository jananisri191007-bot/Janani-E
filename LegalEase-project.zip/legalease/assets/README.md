Place an optional `legalease_logo.png` here to brand generated DOCX and PDF files. If no logo is supplied, exports still work.
