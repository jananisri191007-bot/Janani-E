from fastapi.testclient import TestClient

from backend.main import app
from backend.api import routes

client = TestClient(app)


def test_root_health():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_generate_with_mock(monkeypatch):
    class FakeGenerator:
        def generate_document(self, document_type, parties, terms, dates):
            return f"{document_type}\n\nParties: {parties}\nDate: {dates}\nTerms: {terms}"

    monkeypatch.setattr(routes, "GeminiDocumentGenerator", FakeGenerator)
    response = client.post("/generate", json={
        "document_type": "NDA",
        "parties": "A and B",
        "terms": "Confidentiality applies; No disclosure",
        "dates": "2026-09-29",
    })
    assert response.status_code == 200
    assert "NDA" in response.json()["content"]


def test_generate_validation():
    response = client.post("/generate", json={"document_type": "", "parties": "A", "terms": "B", "dates": "C"})
    assert response.status_code == 422
