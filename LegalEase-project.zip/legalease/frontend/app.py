import html
import os
from datetime import date

import requests
import streamlit as st

from backend.services.document_service import format_docx, format_html_preview, format_pdf, sanitize_text

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

API_URL = os.getenv("LEGALEASE_API_URL", "http://localhost:8000")

st.markdown("""
<style>
.hero { padding: 1.2rem 1.5rem; border-radius: 18px; background: linear-gradient(135deg,#111827,#1f2937); color:white; margin-bottom:1rem; }
.hero h1 { margin:0; font-size:2.2rem; }
.hero p { margin:.4rem 0 0; color:#d1d5db; }
.legal-preview { background:#111827; color:#f9fafb; border-radius:14px; padding:28px; max-height:620px; overflow:auto; font-family: Georgia, serif; line-height:1.65; }
.legal-preview h3 { color:#fff; margin-top:1.2rem; }
.notice { padding:.75rem 1rem; border-left:4px solid #6b7280; background:#f3f4f6; margin:1rem 0; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>⚖️ LegalEase</h1><p>AI-assisted legal document drafting with editable previews and branded exports.</p></div>', unsafe_allow_html=True)
st.markdown('<div class="notice">LegalEase generates drafts for informational and drafting assistance. Have a qualified legal professional review a document before signing or relying on it.</div>', unsafe_allow_html=True)

with st.form("document_form"):
    col1, col2 = st.columns(2)
    with col1:
        document_type = st.text_input("Document Type", placeholder="e.g. Non-Disclosure Agreement")
        parties = st.text_area("Parties Involved", placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)", height=120)
    with col2:
        effective_date = st.date_input("Effective Date", value=date.today())
        terms = st.text_area("Terms & Conditions", placeholder="Payment within 30 days; Confidentiality applies; Either party may terminate with 15 days notice", height=120)
    submitted = st.form_submit_button("Generate Document", type="primary", use_container_width=True)

if submitted:
    if not all([document_type.strip(), parties.strip(), terms.strip()]):
        st.error("Please complete the document type, parties, and terms fields.")
    else:
        payload = {"document_type": document_type, "parties": parties, "terms": terms, "dates": effective_date.isoformat()}
        try:
            with st.spinner("Generating your draft..."):
                response = requests.post(f"{API_URL}/generate", json=payload, timeout=130)
            if response.ok:
                data = response.json()
                st.session_state["document_type"] = data["document_type"]
                st.session_state["terms"] = terms
                st.session_state["content"] = sanitize_text(data["content"])
                st.session_state["model"] = data.get("model", "")
                st.success("Document generated successfully.")
            else:
                try:
                    detail = response.json().get("detail", response.text)
                except ValueError:
                    detail = response.text
                st.error(f"Backend error ({response.status_code}): {detail}")
        except requests.RequestException as exc:
            st.error(f"Could not reach the FastAPI backend at {API_URL}. Start the backend and try again. Details: {exc}")

if "content" in st.session_state:
    st.divider()
    st.subheader("Document Preview")
    st.caption(f"Model: {st.session_state.get('model', 'configured backend model')}")
    st.markdown(format_html_preview(st.session_state["content"]), unsafe_allow_html=True)

    if st.button("Click to Edit Document", use_container_width=True):
        st.session_state["editing"] = True

    if st.session_state.get("editing"):
        edited = st.text_area("Edit Document", value=st.session_state["content"], height=500)
        if st.button("Save Edits", type="primary"):
            st.session_state["content"] = sanitize_text(edited)
            st.session_state["editing"] = False
            st.rerun()

    content = st.session_state["content"]
    doc_type = st.session_state.get("document_type", "Legal Document")
    terms = st.session_state.get("terms", "")
    txt_bytes = content.encode("utf-8")
    docx_bytes = format_docx(content, doc_type, terms)
    pdf_bytes = format_pdf(content, doc_type)

    st.subheader("Download")
    d1, d2, d3 = st.columns(3)
    with d1:
        st.download_button("Download TXT", txt_bytes, file_name="legalease_document.txt", mime="text/plain", use_container_width=True)
    with d2:
        st.download_button("Download DOCX", docx_bytes, file_name="legalease_document.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
    with d3:
        st.download_button("Download PDF", pdf_bytes, file_name="legalease_document.pdf", mime="application/pdf", use_container_width=True)
